package com.accmex.lib;

public class MyClass {
}
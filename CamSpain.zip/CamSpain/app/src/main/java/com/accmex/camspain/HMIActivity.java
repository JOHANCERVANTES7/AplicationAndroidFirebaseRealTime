package com.accmex.camspain;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.widget.TextView;

import com.ekn.gruzer.gaugelibrary.ArcGauge;
import com.ekn.gruzer.gaugelibrary.HalfGauge;
import com.ekn.gruzer.gaugelibrary.Range;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.annotations.concurrent.Background;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class HMIActivity extends AppCompatActivity {
    ArcGauge IdTempMedi;
    double SerarGrafica;
    private String men, text, tAmps;
    private TextView txtTitulo, txtTitulo2;

    private TextView txtTemp2, txtAmps2, txtTemp, txtAmps;
    private int color,colors, backgrownd, backgrownds;

    private static boolean isFirebaseInitialized = false;
    com.ekn.gruzer.gaugelibrary.Range Rango_1,Rango_2,Rango_3;
    HalfGauge IdTempMedior;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hmiactivity);
        IdTempMedi = findViewById(R.id.arcGauge);
        IdTempMedior = findViewById(R.id.idMedidor);
        txtTemp = (TextView) findViewById(R.id.textTemperature);
        txtTitulo = (TextView) findViewById(R.id.textView16);
        txtTitulo2 = (TextView) findViewById(R.id.textView20);
        txtAmps2 = (TextView) findViewById(R.id.TextAmps);
        txtTemp2 = (TextView) findViewById(R.id.TextTemper);


        txtAmps = (TextView) findViewById(R.id.textAmps2);
        setTitle("PRODUCCIÓN");

        txtTitulo.setPaintFlags(txtTitulo.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        txtTitulo2.setPaintFlags(txtTitulo2.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);


        Rango_1 = new Range();
        Rango_2 = new Range();
        Rango_3 = new Range();

        Rango_1.setFrom(0);
        Rango_1.setTo(70);
        Rango_2.setFrom(71);
        Rango_2.setTo(80);
        Rango_3.setFrom(81);
        Rango_3.setTo(100);

        Rango_1.setColor(Color.parseColor("#00c942"));
        Rango_2.setColor(Color.parseColor("#cccc00"));
        Rango_3.setColor(Color.parseColor("#ce0000"));
        IdTempMedior.setMinValue(0);
        IdTempMedior.setMaxValue(100);
        IdTempMedior.setValue(0);

        IdTempMedior.addRange(Rango_1);
        IdTempMedior.addRange(Rango_2);
        IdTempMedior.addRange(Rango_3);

        Range range = new Range();
        range.setColor(Color.parseColor("#73c2fb"));
        range.setFrom(0.0);
        range.setTo(15.0);

        Range range2 = new Range();
        range2.setColor(Color.parseColor("#00c942"));
        range2.setFrom(16.0);
        range2.setTo(36.0);

        Range range3 = new Range();
        range3.setColor(Color.parseColor("#ce0000"));
        range3.setFrom(37.0);
        range3.setTo(100.0);


//add color ranges to gauge
        IdTempMedi.addRange(range);
        IdTempMedi.addRange(range2);
        IdTempMedi.addRange(range3);


//set min max and current value
        IdTempMedi.setMinValue(0.0);
        IdTempMedi.setMaxValue(100.0);
        IdTempMedi.setValue(0.0);

        FirebaseOptions options2 = new FirebaseOptions.Builder()
                .setApiKey("AIzaSyAwx5PAYGJ_ORs0y3uJ-O_cJOVzY14bJQ")
                .setApplicationId("1:1016661296126:android:9540631b1c30046fa136af")
                .setDatabaseUrl("https://h-m-i-1c7e2-default-rtdb.firebaseio.com")
                .build();

        if (!isFirebaseInitialized) {
            FirebaseApp.initializeApp(this /* Context */, options2, "databases2");
            isFirebaseInitialized = true;
        }
        FirebaseDatabase database2 = FirebaseDatabase.getInstance(FirebaseApp.getInstance("databases2"));
        DatabaseReference usuariosRef = database2.getReference().child("/HMI/PRODUCCION");
        usuariosRef.addValueEventListener(new ValueEventListener() {
                                              @Override
                                              public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                  double amps = Double.parseDouble(dataSnapshot.child("AMPS").getValue().toString());
                                                  SerarGrafica = amps;
                                                  IdTempMedior.setValue(SerarGrafica);
                                                  if(amps ==0 ){
                                                      tAmps = "sin lectura de datos " +amps ;
                                                      colors = Color.parseColor("#008f39");
                                                      color = Color.parseColor("#161626");
                                                  }

                                                  if(amps >0 && amps<=70){
                                                      tAmps = "Correcto " +amps ;
                                                      colors = Color.parseColor("#008f39");
                                                      color = Color.parseColor("#161626");
                                                  }
                                                  if(amps >=71 && amps<=80){
                                                      tAmps = " Advertencia " +amps ;
                                                      colors = Color.parseColor("#daa520");
                                                      color = Color.parseColor("#161626");

                                                  }
                                                  if(amps >=81){
                                                      tAmps = "Peligro " +amps ;
                                                      colors = Color.parseColor("#FF0000");
                                                      color = Color.parseColor("#161626");

                                                  }
                                                  txtAmps.setText(tAmps);
                                                  txtAmps.setTextColor(colors);
                                                  txtAmps.setBackgroundColor(Color.parseColor("#BFBABA"));
                                                  txtAmps2.setText("Amps "+ amps);
                                                  txtAmps2.setTextColor(Color.WHITE);

                                              }

                                              @Override
                                              public void onCancelled(@NonNull DatabaseError error) {

                                              }
                                          });
            DatabaseReference usuariosRefs = database2.getReference().child("/HMI/PRODUCCION");
        usuariosRefs.addValueEventListener(new ValueEventListener() {

            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                double Temp = Double.parseDouble(dataSnapshot.child("TEMPERATURA").getValue().toString());
                SerarGrafica = Temp;
                IdTempMedi.setValue(SerarGrafica);
                if(Temp ==0 ){
                    text = "sin lectura de datos " +Temp + "°C";
                    color = Color.parseColor("#0000cc");
                    colors = Color.parseColor("#161626");
                }
                if(Temp >0 && Temp<=15){
                    text = " Baja " +Temp + "°C";
                    color = Color.parseColor("#0000cc");
                    colors = Color.parseColor("#161626");
                }
                if(Temp >=16 && Temp<=36){
                    text = " Moderada " +Temp + "°C";
                   color = Color.parseColor("#00c942");
                    colors = Color.parseColor("#161626");

                }if(Temp >=37 ){
                    text = " Extrema " +Temp + "°C";
                    colors = Color.parseColor("#161626");
                    color = Color.WHITE;
                }

                if (Temp >= 37) {

                    ObjectAnimator animator = ObjectAnimator.ofArgb(txtTemp, "backgroundColor", Color.WHITE, Color.RED);
                    animator.setDuration(1000);
                    animator.setRepeatCount(ValueAnimator.INFINITE);
                    animator.setRepeatMode(ValueAnimator.REVERSE);
                    animator.start();
                    men = "Temperatura alta";
                    alerta(men);

                } else {
                    txtTemp.setTextColor(Color.parseColor("#0000FF"));
                    txtTemp.setBackgroundColor(colors);
                    ObjectAnimator animator = ObjectAnimator.ofArgb(txtTemp, "backgroundColor", Color.parseColor("#BFBABA"), Color.parseColor("#BFBABA"));
                    animator.setDuration(1000);
                    animator.setRepeatCount(ValueAnimator.INFINITE);
                    animator.setRepeatMode(ValueAnimator.REVERSE);
                    animator.start();
                }
                    txtTemp.setText(text);
                    txtTemp.setTextColor(color);
                    txtTemp.setBackgroundColor(Color.parseColor("#BFBABA"));
                    txtTemp2.setText(Temp + "°C");
                    txtTemp2.setTextColor(Color.WHITE);

            }

            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
    public void alerta (String men){
        String mensa = this.men;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Cuidado");
        builder.setMessage(mensa);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // acción cuando se hace clic en OK
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
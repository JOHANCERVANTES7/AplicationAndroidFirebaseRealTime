package com.accmex.camspain

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageButton
import android.widget.Toast


class MEnusActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menus)

        title="Camaras"


        val btnCam1 = findViewById<ImageButton>(R.id.Cam1Button)
        val btnCam2 = findViewById<ImageButton>(R.id.Cam2Button)
        val btnCam3 = findViewById<ImageButton>(R.id.Cam3Button)
        val btnCam4 = findViewById<ImageButton>(R.id.Cam4Button)
        val btnCam5 = findViewById<ImageButton>(R.id.Cam5Button)
        val btnCam6 = findViewById<ImageButton>(R.id.Cam6Button)


        btnCam1.setOnClickListener {
            val Intent = Intent(this, ControlActivity::class.java)
            startActivity(Intent)
        }
        btnCam2.setOnClickListener {
            val Intent = Intent(this, CamCon2Activity::class.java)
            startActivity(Intent)

        }
        btnCam3.setOnClickListener {
            val Intent = Intent(this, CamCon3Activity::class.java)
            startActivity(Intent)

        }
        btnCam4.setOnClickListener {
            val Intent = Intent(this, CamCon4Activity::class.java)
            startActivity(Intent)

        }
        btnCam5.setOnClickListener {
            val Intent = Intent(this, CamCon5Activity::class.java)
            startActivity(Intent)

        }
        btnCam6.setOnClickListener {
            val Intent = Intent(this, CamCon6Activity::class.java)
            startActivity(Intent)

        }
    }



}
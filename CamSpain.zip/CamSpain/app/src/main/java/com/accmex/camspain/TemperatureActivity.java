package com.accmex.camspain;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.ekn.gruzer.gaugelibrary.HalfGauge;
import com.ekn.gruzer.gaugelibrary.Range;
import com.github.mikephil.charting.charts.LineChart;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class TemperatureActivity extends AppCompatActivity {

    private TextView mtxtTemp;
    private TextView mtxtTemp2;
    private TextView mtxtTemp3;
    private String men;
    private TextView mtxtTemp4;
    private TextView mtxtTemp5;
    private TextView mtxtTemp6;
    private ConstraintLayout mtxtCuidado;
    private DatabaseReference mDatabse;

    private int array[];
    com.ekn.gruzer.gaugelibrary.Range Rango_1,Rango_2,Rango_3;
    HalfGauge IdTempMedi;
    HalfGauge IdTempMedi2;
    HalfGauge IdTempMedi3;
    HalfGauge IdTempMedi4;
    HalfGauge IdTempMedi5;
    HalfGauge IdTempMedi6;
    double SerarGrafica;
    LineChart mpLineChart;
    private ImageButton button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature);
        setTitle("Temperatura");


        mDatabse = FirebaseDatabase.getInstance().getReference();

        mtxtTemp = (TextView) findViewById(R.id.textTemperatura);
        mtxtTemp2 = (TextView) findViewById(R.id.textTemperatura2);
        mtxtTemp3 = (TextView) findViewById(R.id.textTemperatura3);
        mtxtTemp4 = (TextView) findViewById(R.id.textTemperatura4);
        mtxtTemp5 = (TextView) findViewById(R.id.textTemperatura5);
        mtxtTemp6 = (TextView) findViewById(R.id.textTemperatura6);
        mtxtCuidado = (ConstraintLayout) findViewById(R.id.Fondo);
        IdTempMedi = findViewById(R.id.idMedidor);
        IdTempMedi2 = findViewById(R.id.IdMedidor2);
        IdTempMedi3 = findViewById(R.id.idMedidor3);
        IdTempMedi4 = findViewById(R.id.idMedidor4);
        IdTempMedi5 = findViewById(R.id.idMedidor5);
        IdTempMedi6 = findViewById(R.id.idMedidor6);


        IdTempMedi.setOnClickListener(v ->{
            onClick(v);
                });

        IdTempMedi2.setOnClickListener(v ->{
            onClick2(v);
        });

        IdTempMedi3.setOnClickListener(v ->{
            onClick3(v);
        });

        IdTempMedi4.setOnClickListener(v ->{
            onClick4(v);
        });
        IdTempMedi5.setOnClickListener(v ->{
            onClick5(v);
        });
        IdTempMedi6.setOnClickListener(v ->{
            onClick6(v);
        });
        mtxtTemp.setOnClickListener(v ->{
            onClick(v);
        });

        mtxtTemp2.setOnClickListener(v ->{
            onClick2(v);
        });

        mtxtTemp3.setOnClickListener(v ->{
            onClick3(v);
        });

        mtxtTemp4.setOnClickListener(v ->{
            onClick4(v);
        });
        mtxtTemp5.setOnClickListener(v ->{
            onClick5(v);
        });

        mtxtTemp6.setOnClickListener(v ->{
            onClick6(v);
        });


        Rango_1 = new Range();
        Rango_2 = new Range();
        Rango_3 = new Range();

        Rango_1.setFrom(-50);
        Rango_1.setTo(-30);
        Rango_2.setFrom(-30);
        Rango_2.setTo(-10);
        Rango_3.setFrom(-9);
        Rango_3.setTo(0);

        Rango_1.setColor(Color.BLUE);
        Rango_2.setColor(Color.GREEN);
        Rango_3.setColor(Color.RED);
        IdTempMedi.setMinValue(-50);
        IdTempMedi.setMaxValue(0);
        IdTempMedi.setValue(0);

        IdTempMedi.addRange(Rango_1);
        IdTempMedi.addRange(Rango_2);
        IdTempMedi.addRange(Rango_3);

        IdTempMedi2.setMinValue(-50);
        IdTempMedi2.setMaxValue(0);
        IdTempMedi2.setValue(0);

        IdTempMedi2.addRange(Rango_1);
        IdTempMedi2.addRange(Rango_2);
        IdTempMedi2.addRange(Rango_3);

        IdTempMedi3.setMinValue(-50);
        IdTempMedi3.setMaxValue(0);
        IdTempMedi3.setValue(0);

        IdTempMedi3.addRange(Rango_1);
        IdTempMedi3.addRange(Rango_2);
        IdTempMedi3.addRange(Rango_3);

        IdTempMedi4.setMinValue(-50);
        IdTempMedi4.setMaxValue(0);
        IdTempMedi4.setValue(0);

        IdTempMedi4.addRange(Rango_1);
        IdTempMedi4.addRange(Rango_2);
        IdTempMedi4.addRange(Rango_3);

        IdTempMedi5.setMinValue(-50);
        IdTempMedi5.setMaxValue(0);
        IdTempMedi5.setValue(0);

        IdTempMedi5.addRange(Rango_1);
        IdTempMedi5.addRange(Rango_2);
        IdTempMedi5.addRange(Rango_3);

        IdTempMedi6.setMinValue(-50);
        IdTempMedi6.setMaxValue(0);
        IdTempMedi6.setValue(0);

        IdTempMedi6.addRange(Rango_1);
        IdTempMedi6.addRange(Rango_2);
        IdTempMedi6.addRange(Rango_3);

        mDatabse.child("CAMARA1/Temperatura/Sensor1").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {
                    double Temp = Double.parseDouble(dataSnapshot.child("Valor").getValue().toString());
                    mtxtTemp.setText(Temp + "°C.");
                    if (Temp > -10) {
                        mtxtTemp.setTextColor(Color.parseColor("#FF0000"));


                       } else {
                        mtxtTemp.setTextColor(Color.parseColor("#0000FF"));
                        ObjectAnimator animator = ObjectAnimator.ofArgb(mtxtCuidado, "backgroundColor", Color.WHITE, Color.WHITE);
                        animator.setDuration(1000);
                        animator.setRepeatCount(ValueAnimator.INFINITE);
                        animator.setRepeatMode(ValueAnimator.REVERSE);
                        animator.start();
                        }
                    SerarGrafica = Temp;
                    IdTempMedi.setValue(SerarGrafica);
                } else {
                    mtxtTemp.setText(" la Temperatura no cargo");

                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
                mDatabse.child("CAMARA2/Temperatura/Sensor1").addValueEventListener(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        if (dataSnapshot.exists()) {
                            double Temp = Double.parseDouble(dataSnapshot.child("Valor").getValue().toString());
                            mtxtTemp2.setText(Temp + "°C.");
                            if (Temp > -10) {
                                mtxtTemp2.setTextColor(Color.parseColor("#FF0000"));
                                ObjectAnimator animator = ObjectAnimator.ofArgb(mtxtCuidado, "backgroundColor", Color.WHITE, Color.RED);
                                animator.setDuration(1000);
                                animator.setRepeatCount(ValueAnimator.INFINITE);
                                animator.setRepeatMode(ValueAnimator.REVERSE);
                                animator.start();
                                men = "Camara 2";
                                alerta(men);
                                } else {
                                mtxtTemp2.setTextColor(Color.parseColor("#0000FF"));
                                ObjectAnimator animator = ObjectAnimator.ofArgb(mtxtCuidado, "backgroundColor", Color.WHITE, Color.WHITE);
                                animator.setDuration(1000);
                                animator.setRepeatCount(ValueAnimator.INFINITE);
                                animator.setRepeatMode(ValueAnimator.REVERSE);
                                animator.start();
                                 }
                            SerarGrafica = Temp;
                            IdTempMedi2.setValue(SerarGrafica);
                        } else {
                            mtxtTemp2.setText(" la Temperatura no cargo");

                        }
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
        mDatabse.child("CAMARA3/Temperatura/Sensor1").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {
                    double Temp = Double.parseDouble(dataSnapshot.child("Valor").getValue().toString());
                    mtxtTemp3.setText(Temp + "°C.");
                    if (Temp > -10) {
                        mtxtTemp3.setTextColor(Color.parseColor("#FF0000"));
                        ObjectAnimator animator = ObjectAnimator.ofArgb(mtxtCuidado, "backgroundColor", Color.WHITE, Color.RED);
                        animator.setDuration(1000);
                        animator.setRepeatCount(ValueAnimator.INFINITE);
                        animator.setRepeatMode(ValueAnimator.REVERSE);
                        animator.start();
                        men = "Camara 3";
                        alerta(men);
                        } else {
                        mtxtTemp3.setTextColor(Color.parseColor("#0000FF"));
                        ObjectAnimator animator = ObjectAnimator.ofArgb(mtxtCuidado, "backgroundColor", Color.WHITE, Color.WHITE);
                        animator.setDuration(1000);
                        animator.setRepeatCount(ValueAnimator.INFINITE);
                        animator.setRepeatMode(ValueAnimator.REVERSE);
                        animator.start();
                        }
                    SerarGrafica = Temp;
                    IdTempMedi3.setValue(SerarGrafica);
                } else {
                    mtxtTemp3.setText(" la Temperatura no cargo");

                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        mDatabse.child("CAMARA4/Temperatura/Sensor1").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {
                    double Temp = Double.parseDouble(dataSnapshot.child("Valor").getValue().toString());
                    mtxtTemp4.setText(Temp + "°C.");
                    if (Temp > -10) {
                        mtxtTemp4.setTextColor(Color.parseColor("#FF0000"));
                        ObjectAnimator animator = ObjectAnimator.ofArgb(mtxtCuidado, "backgroundColor", Color.WHITE, Color.RED);
                        animator.setDuration(1000);
                        animator.setRepeatCount(ValueAnimator.INFINITE);
                        animator.setRepeatMode(ValueAnimator.REVERSE);
                        animator.start();
                        men = "Camara 4";
                        alerta(men);
                         } else {
                        mtxtTemp4.setTextColor(Color.parseColor("#0000FF"));
                        ObjectAnimator animator = ObjectAnimator.ofArgb(mtxtCuidado, "backgroundColor", Color.WHITE, Color.WHITE);
                        animator.setDuration(1000);
                        animator.setRepeatCount(ValueAnimator.INFINITE);
                        animator.setRepeatMode(ValueAnimator.REVERSE);
                        animator.start();
                        }
                    SerarGrafica = Temp;
                    IdTempMedi4.setValue(SerarGrafica);
                } else {
                    mtxtTemp4.setText(" la Temperatura no cargo");

                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        }); mDatabse.child("CAMARA5/Temperatura/Sensor1").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {
                    double Temp = Double.parseDouble(dataSnapshot.child("Valor").getValue().toString());
                    mtxtTemp5.setText(Temp + "°C.");
                    if (Temp > -10) {
                        mtxtTemp5.setTextColor(Color.parseColor("#FF0000"));
                        ObjectAnimator animator = ObjectAnimator.ofArgb(mtxtCuidado, "backgroundColor", Color.WHITE, Color.RED);
                        animator.setDuration(1000);
                        animator.setRepeatCount(ValueAnimator.INFINITE);
                        animator.setRepeatMode(ValueAnimator.REVERSE);
                        animator.start();
                        men = "Camara 5";
                        alerta(men);
                        } else {
                        mtxtTemp5.setTextColor(Color.parseColor("#0000FF"));
                        ObjectAnimator animator = ObjectAnimator.ofArgb(mtxtCuidado, "backgroundColor", Color.WHITE, Color.WHITE);
                        animator.setDuration(1000);
                        animator.setRepeatCount(ValueAnimator.INFINITE);
                        animator.setRepeatMode(ValueAnimator.REVERSE);
                        animator.start();
                       }
                    SerarGrafica = Temp;
                    IdTempMedi5.setValue(SerarGrafica);
                } else {
                    mtxtTemp5.setText(" la Temperatura no cargo");

                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabse.child("CAMARA6/Temperatura/Sensor1").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {
                    double Temp = Double.parseDouble(dataSnapshot.child("Valor").getValue().toString());
                    mtxtTemp6.setText(Temp + "°C.");
                    if (Temp > -10) {
                        mtxtTemp6.setTextColor(Color.parseColor("#FF0000"));
                        ObjectAnimator animator = ObjectAnimator.ofArgb(mtxtCuidado, "backgroundColor", Color.WHITE, Color.RED);
                        animator.setDuration(1000);
                        animator.setRepeatCount(ValueAnimator.INFINITE);
                        animator.setRepeatMode(ValueAnimator.REVERSE);
                        animator.start();
                        men = "Camara 6";
                        alerta(men);
                        } else {
                        mtxtTemp6.setTextColor(Color.parseColor("#0000FF"));
                        ObjectAnimator animator = ObjectAnimator.ofArgb(mtxtCuidado, "backgroundColor", Color.WHITE, Color.WHITE);
                        animator.setDuration(1000);
                        animator.setRepeatCount(ValueAnimator.INFINITE);
                        animator.setRepeatMode(ValueAnimator.REVERSE);
                        animator.start();
                        }
                    SerarGrafica = Temp;
                    IdTempMedi6.setValue(SerarGrafica);
                } else {
                    mtxtTemp6.setText(" la Temperatura no cargo");

                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

        public void onClick(View view){
            Intent intent = new Intent(this,GraficaActivity.class);
            startActivity(intent);
        }

    public void onClick2(View view){
        Intent intent = new Intent(this,GraficaActivity2.class);
        startActivity(intent);
    }
    public void onClick3(View view){
        Intent intent = new Intent(this,GraficaActivity3.class);
        startActivity(intent);
    }
    public void onClick4(View view){
        Intent intent = new Intent(this,GraficaActivity4.class);
        startActivity(intent);
    }
    public void onClick5(View view){
        Intent intent = new Intent(this,GraficaActivity5.class);
        startActivity(intent);
    }
    public void onClick6(View view){
        Intent intent = new Intent(this,GraficaActivity6.class);
        startActivity(intent);
    }
    public void alerta(String men){
        String mensa = this.men;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Cuidado");
        builder.setMessage("Temperatura Alta en " + mensa);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // acción cuando se hace clic en OK
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }


    }
    

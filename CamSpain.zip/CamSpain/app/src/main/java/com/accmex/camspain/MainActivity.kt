package com.accmex.camspain

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputFilter
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase


class MainActivity : AppCompatActivity() {
// login
    private val GOOGLE_SIGN_IN = 100
    override fun onBackPressed() {
       showAlertSec()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       lateinit var auth: FirebaseAuth;
        auth = Firebase.auth
        setContentView(R.layout.activity_main)
   setup()

    }
    private fun setup(){
        //titulo de app app de android
        title="Autenticación"
        // variables y asignamiento de cada variable a un elemento del diseño
        val txtUsuario = findViewById<EditText>(R.id.editTextUsuario)
        val txtPassword = findViewById<EditText>(R.id.editTextPassword)
        val btnLogin = findViewById<Button>(R.id.loginButton)
        val btnGoogle = findViewById<Button>(R.id.googleButton)
        val filter = InputFilter { source, start, end, dest, dstart, dend ->
            // Elimina los espacios en blanco al final del texto ingresado por el usuario
            if (end > 0 && source?.get(end - 1)?.isWhitespace() == true) {
                source.subSequence(start, end - 1)
            } else {
                source
            }

        }


        // metodo para el registro de nuevos usuarios
        findViewById<Button>(R.id.signUpButton).setOnClickListener{
            if (txtUsuario.text.isNotEmpty() && txtPassword.text.isNotEmpty()){
                txtUsuario.filters = arrayOf(filter)
                FirebaseAuth.getInstance()
                    .createUserWithEmailAndPassword(txtUsuario.text.toString(),
                txtPassword.text.toString()).addOnCompleteListener{


                    if(it.isSuccessful){
                        txtUsuario.setText("")
                        txtPassword.setText("")
                        showHome(it.result?.user?.email?:"", ProviderType.BASIC)

                    }else{
                        showAlert()
                    }
                }

            }
        }
        // metodo para el logeo de usuarios ya existentes
        btnLogin.setOnClickListener{
            findViewById<Button>(R.id.loginButton).setOnClickListener{
                txtUsuario.filters = arrayOf(filter)
                if (txtUsuario.text.isNotEmpty() && txtPassword.text.isNotEmpty()){

                    txtUsuario.filters = arrayOf(filter)

                    FirebaseAuth.getInstance()
                        .signInWithEmailAndPassword(txtUsuario.text.toString(),
                        txtPassword.text.toString()).addOnCompleteListener{
                        if(it.isSuccessful){
                            txtUsuario.setText("")
                            txtPassword.setText("")
                            showHome(it.result?.user?.email?:"", ProviderType.BASIC)

                        }else{
                            showAlertMostUsu()

                        }
                    }

                }
            }
        }
        // autenticacion por cuentas google
        btnGoogle.setOnClickListener{
            val googleConfig = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build()

            val googleClient:GoogleSignInClient = GoogleSignIn.getClient(this, googleConfig)
            googleClient.signOut()
            startActivityForResult(googleClient.signInIntent, GOOGLE_SIGN_IN)
        }
    }
    // Alertas
    private fun showAlert() {
        val builder =AlertDialog.Builder(this)
        builder.setTitle("Error")
        builder.setMessage("no se a podido registrar al usuario")
        builder.setPositiveButton("aceptar",null)
        val dialog:AlertDialog = builder.create()
        dialog.show()
    }
    private fun showAlertSec() {
        val builder =AlertDialog.Builder(this)
        builder.setTitle("Advertencia")
        builder.setMessage("No has iniciado sesion")
        builder.setPositiveButton("aceptar",null)
        val dialog:AlertDialog = builder.create()
        dialog.show()
    }
    private fun showAlertMostUsu() {
        val builder =AlertDialog.Builder(this)
        builder.setTitle("Error")
        builder.setMessage("el correo o contraseña son incorrectos")
        builder.setPositiveButton("aceptar",null)
        val dialog:AlertDialog = builder.create()
        dialog.show()
    }
    private fun showHome(email: String, provider: ProviderType){

    val homeIntent = Intent(this, PrincipalActivity::class.java).apply {
        putExtra("email",email)
        putExtra("provider",provider.name)
    }
startActivity(homeIntent)
    }
    // metodo completo de logeo por cuentas de google
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(requestCode == GOOGLE_SIGN_IN){
            val task:Task<GoogleSignInAccount> = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account: GoogleSignInAccount = task.getResult(ApiException::class.java)

                if (account != null) {
                    val credential: AuthCredential =
                        GoogleAuthProvider.getCredential(account.idToken, null)
                    FirebaseAuth.getInstance().signInWithCredential(credential)
                        .addOnCompleteListener {

                            if (it.isSuccessful) {
                                showHome(account.email ?: "", ProviderType.GOOGLE)
                            } else {
                                showAlert()
                            }
                        }
                }
            }catch (e:ApiException){
                showAlert()
            }
        }
    }
}
package com.accmex.camspain;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class CamCon6Activity extends AppCompatActivity {


    private Button BtnD3;
    private Button BtnK1;
    private Button BtnK1M;
    private Button BtnK2m;
    private Button BtnMarch;
    private Button BtnRecGas;
    private Button BtnRole1;
    private Button BtnRole2;
    private Button BtnResis;
    private Button BtnSolenoide;
    private Button BtnVentilador;
    private DatabaseReference mDatabse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cam_con6);

        setTitle("Control Camara 6");

        BtnK1 = findViewById(R.id.buttonK1);
        BtnK1M =findViewById(R.id.buttonk1M);
        BtnK2m = findViewById(R.id.buttonK2M);
        BtnMarch = findViewById(R.id.buttonMarcha);
        BtnRole1 = findViewById(R.id.buttonRole1);
        BtnRecGas = findViewById(R.id.buttonRecogida);
        BtnRole2 = findViewById(R.id.buttonRele2);
        BtnResis = findViewById(R.id.buttonCarter);
        BtnSolenoide = findViewById(R.id.buttonSolenoide);
        BtnVentilador = findViewById(R.id.buttonVentilador);
        BtnD3 = findViewById(R.id.buttonD3);
        mDatabse = FirebaseDatabase.getInstance().getReference();

        mDatabse.child("CAMARA6/Equipos").addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    int D3 = Integer.parseInt(dataSnapshot.child("D3").getValue().toString());
                    int K1 = Integer.parseInt(dataSnapshot.child("K1").getValue().toString());
                    int K1M = Integer.parseInt(dataSnapshot.child("K1M").getValue().toString());
                    int K2M = Integer.parseInt(dataSnapshot.child("K2M").getValue().toString());
                    int Marcha = Integer.parseInt(dataSnapshot.child("Marcha").getValue().toString());
                    int RecGas = Integer.parseInt(dataSnapshot.child("Recogida_de_gas").getValue().toString());
                    int Role1 = Integer.parseInt(dataSnapshot.child("Rele_seco_1").getValue().toString());
                    int Rele2 = Integer.parseInt(dataSnapshot.child("Rele_seco_2").getValue().toString());
                    int Reesis = Integer.parseInt(dataSnapshot.child("Resistencia_carter").getValue().toString());
                    int Solenoide = Integer.parseInt(dataSnapshot.child("Solenoide_liquido").getValue().toString());
                    int Ventilador = Integer.parseInt(dataSnapshot.child("Ventilador_evaporado").getValue().toString());


                    GradientDrawable gd = new GradientDrawable();
                    GradientDrawable gd1 = new GradientDrawable();
                    GradientDrawable gd2 = new GradientDrawable();
                    GradientDrawable gd3 = new GradientDrawable();
                    GradientDrawable gd4 = new GradientDrawable();
                    GradientDrawable gd5 = new GradientDrawable();
                    GradientDrawable gd6 = new GradientDrawable();
                    GradientDrawable gd7 = new GradientDrawable();
                    GradientDrawable gd8 = new GradientDrawable();
                    GradientDrawable gd9 = new GradientDrawable();
                    GradientDrawable gd10 = new GradientDrawable();
                    GradientDrawable gd11 = new GradientDrawable();

                    if (D3 == 1) {
                        gd.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd.setStroke(10, Color.BLACK);
                        BtnD3.setBackground(gd);
                        BtnD3.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        BtnD3.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> D3Map = new HashMap<>();
                                D3Map.put("D3",0);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(D3Map);

                            }
                        });


                    } else {
                        gd.setCornerRadius(40);
                        gd.setStroke(10, Color.BLACK);
                        BtnD3.setBackground(gd);
                        BtnD3.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                        BtnD3.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> D3Map = new HashMap<>();
                                D3Map.put("D3",1);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(D3Map);
                            }
                        });
                    }
                    if (K1 == 1) {
                        gd1.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd1.setStroke(10, Color.BLACK);
                        BtnK1.setBackground(gd1);
                        BtnK1.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        BtnK1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("K1",0);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    } else {
                        gd1.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd1.setStroke(10, Color.BLACK);
                        BtnK1.setBackground(gd1);
                        BtnK1.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                        BtnK1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("K1",1);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    }if (K1M == 1) {
                        gd2.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd2.setStroke(10, Color.BLACK);
                        BtnK1M.setBackground(gd2);
                        BtnK1M.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        BtnK1M.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("K1M",0);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    } else {
                        gd2.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd2.setStroke(10, Color.BLACK);
                        BtnK1M.setBackground(gd2);
                        BtnK1M.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                        BtnK1M.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("K1M",1);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    }
                    if (K2M == 1) {
                        gd3.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd3.setStroke(10, Color.BLACK);
                        BtnK2m.setBackground(gd3);
                        BtnK2m.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        BtnK2m.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("K2M",0);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    } else {
                        gd3.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd3.setStroke(10, Color.BLACK);
                        BtnK2m.setBackground(gd3);
                        BtnK2m.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                        BtnK2m.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("K2M",1);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    }
                    if (Marcha == 1) {
                        gd4.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd4.setStroke(10, Color.BLACK);
                        BtnMarch.setBackground(gd4);
                        BtnMarch.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        BtnMarch.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Marcha",0);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    } else {
                        gd4.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd4.setStroke(10, Color.BLACK);
                        BtnMarch.setBackground(gd4);
                        BtnMarch.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                        BtnMarch.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Marcha",1);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    }
                    if (RecGas == 1) {
                        gd5.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd5.setStroke(10, Color.BLACK);
                        gd5.setColor(Color.GREEN);
                        BtnRecGas.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        BtnRecGas.setBackground(gd5);
                        BtnRecGas.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Recogida_de_gas",0);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    } else {
                        gd5.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd5.setStroke(10, Color.BLACK);
                        BtnRecGas.setBackground(gd5);
                        BtnRecGas.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                        BtnRecGas.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Recogida_de_gas",1);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    }
                    if (Role1 == 1) {
                        gd6.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd6.setStroke(10, Color.BLACK);
                        BtnRole1.setBackground(gd6);
                        BtnRole1.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        BtnRole1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Rele_seco_1",0);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    } else {
                        gd6.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd6.setStroke(10, Color.BLACK);
                        BtnRole1.setBackground(gd6);
                        BtnRole1.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                        BtnRole1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Rele_seco_1",1);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    }
                    if (Rele2 == 1) {
                        gd7.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd7.setStroke(10, Color.BLACK);
                        BtnRole2.setBackground(gd7);
                        BtnRole2.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        BtnRole2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Rele_seco_2",0);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    } else {
                        gd7.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd7.setStroke(10, Color.BLACK);
                        gd7.setColor(Color.RED);
                        BtnRole2.setBackground(gd7);
                        BtnRole2.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                        BtnRole2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Rele_seco_2",1);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    }
                    if (Reesis == 1) {
                        gd8.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd8.setStroke(10, Color.BLACK);
                        BtnResis.setBackground(gd8);
                        BtnResis.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        BtnResis.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Resistencia_carter",0);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    } else {

                        gd8.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd8.setStroke(10, Color.BLACK);
                        BtnResis.setBackground(gd8);
                        BtnResis.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                        BtnResis.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Resistencia_carter",1);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    }
                    if (Solenoide == 1) {
                        gd9.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd9.setStroke(10, Color.BLACK);
                        BtnSolenoide.setBackground(gd9);
                        BtnSolenoide.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        BtnSolenoide.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Solenoide_liquido",0);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    } else {
                        gd9.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd9.setStroke(10, Color.BLACK);
                        BtnSolenoide.setBackground(gd9);
                        BtnSolenoide.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                        BtnSolenoide.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Solenoide_liquido",1);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    }
                    if (Ventilador == 1) {
                        gd10.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd10.setStroke(10, Color.BLACK);
                        BtnVentilador.setBackground(gd10);
                        BtnVentilador.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                        BtnVentilador.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String , Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Ventilador_evaporado",0);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    } else {
                        gd10.setCornerRadius(40); // Define el radio de la esquina del botón
                        gd10.setStroke(10, Color.BLACK);
                        BtnVentilador.setBackground(gd10);
                        BtnVentilador.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                        BtnVentilador.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Map<String, Object> EquiposMap = new HashMap<>();
                                EquiposMap.put("Ventilador_evaporado", 1);
                                mDatabse.child("CAMARA6/Equipos").updateChildren(EquiposMap);
                            }
                        });
                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}
package com.accmex.camspain;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AccessActivity extends AppCompatActivity {

    private TextView mTextViewData;
    private TextView CamNomTxt2;
    private TextView CamNomTxt3;
    private TextView CamNomTxt4;
    private TextView CamNomTxt5;
    private TextView CamNomTxt6;
    private TextView mTextFecha;
    private TextView mtxtpuerta;
    private TextView mtxtEstado;
    private TextView mTextFechaCam2;
    private TextView mtxtpuertaCam2;
    private TextView mtxtEstadoCam2;
    private TextView mTextFechaCam3;
    private TextView mtxtpuertaCam3;
    private TextView mtxtEstadoCam3;
    private TextView mTextFechaCam4;
    private TextView mtxtpuertaCam4;
    private TextView mtxtEstadoCam4;
    private TextView mTextFechaCam5;
    private TextView mtxtpuertaCam5;
    private TextView mtxtEstadoCam5;
    private String men;
    private ImageView Imagen1;
    private ImageView Imagen2;
    private ImageView Imagen3;
    private ImageView Imagen4;
    private ImageView Imagen5;
    private ImageView Imagen6;
    private TextView mTextFechaCam6;
    private TextView mtxtpuertaCam6;
    private TextView mtxtEstadoCam6;

    private DatabaseReference mDatabse;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_access);

        setTitle("Acces");

        mTextViewData = (TextView) findViewById(R.id.NombreText);
        Imagen1 = (ImageView) findViewById(R.id.imageCam1);
        Imagen2 = (ImageView) findViewById(R.id.imageCam2);
        Imagen3 = (ImageView) findViewById(R.id.imageCam3);
        Imagen4 = (ImageView) findViewById(R.id.imageCam4);
        Imagen5 = (ImageView) findViewById(R.id.imageCam5);
        Imagen6 = (ImageView) findViewById(R.id.imageCam6);
        CamNomTxt2 = (TextView) findViewById(R.id.CamNombreText2);
        CamNomTxt3 = (TextView) findViewById(R.id.CamNombreText3);
        CamNomTxt4 = (TextView) findViewById(R.id.CamNombreText4);
        CamNomTxt5 = (TextView) findViewById(R.id.CamNombreText5);
        CamNomTxt6 = (TextView) findViewById(R.id.CamNombreText6);
        mTextFecha = (TextView) findViewById(R.id.FechaText);
        mtxtpuerta = (TextView) findViewById(R.id.textPuerta);
        mTextFechaCam2 = (TextView) findViewById(R.id.FechaTextCam2);
        mtxtpuertaCam2 = (TextView) findViewById(R.id.camTextPuerta);
        mtxtEstadoCam2 = (TextView) findViewById(R.id.textEstadoCam2);
        mTextFechaCam3 = (TextView) findViewById(R.id.FechaTextCam3);
        mtxtpuertaCam3 = (TextView) findViewById(R.id.CamTextPuerta3);
        mtxtEstadoCam3 = (TextView) findViewById(R.id.textEstadoCam3);
        mTextFechaCam4 = (TextView) findViewById(R.id.FechaTextCam4);
        mtxtpuertaCam4 = (TextView) findViewById(R.id.CamTextPuerta4);
        mtxtEstadoCam4 = (TextView) findViewById(R.id.textEstadoCam4);
        mTextFechaCam5 = (TextView) findViewById(R.id.FechaTextCam5);
        mtxtpuertaCam5 = (TextView) findViewById(R.id.CamTextPuerta5);
        mtxtEstadoCam5 = (TextView) findViewById(R.id.textEstadoCam5);
        mTextFechaCam6 = (TextView) findViewById(R.id.FechaTextCam6);
        mtxtpuertaCam6 = (TextView) findViewById(R.id.CamTextPuerta6);
        mtxtEstadoCam6 = (TextView) findViewById(R.id.textEstadoCam6);
        mDatabse = FirebaseDatabase.getInstance().getReference();

        mDatabse.child("CAMARA1/Accesos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()){
                    String Name = dataSnapshot.child("Persona").getValue().toString();
                    String Fecha = dataSnapshot.child("Fecha").getValue().toString();

                    mTextViewData.setText(Name);
                    mTextFecha.setText(Fecha);
                }else {
                    mTextViewData.setText(" los Datos no cargaron correctamente"  );}
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabse.child("CAMARA2/Accesos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()){
                    String Name = dataSnapshot.child("Persona").getValue().toString();
                    String Fecha = dataSnapshot.child("Fecha").getValue().toString();

                    CamNomTxt2.setText(Name);
                    mTextFechaCam2.setText(Fecha);
                }else {
                    mTextViewData.setText(" los Datos no cargaron correctamente"  );}
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabse.child("CAMARA3/Accesos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()){
                    String Name = dataSnapshot.child("Persona").getValue().toString();
                    String Fecha = dataSnapshot.child("Fecha").getValue().toString();

                    CamNomTxt3.setText(Name);
                    mTextFechaCam3.setText(Fecha);
                }else {
                    CamNomTxt3.setText(" los Datos no cargaron correctamente"  );}
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabse.child("CAMARA4/Accesos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()){
                    String Name = dataSnapshot.child("Persona").getValue().toString();
                    String Fecha = dataSnapshot.child("Fecha").getValue().toString();

                    CamNomTxt4.setText(Name);
                    mTextFechaCam4.setText(Fecha);
                }else {
                    CamNomTxt4.setText(" los Datos no cargaron correctamente"  );}
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabse.child("CAMARA5/Accesos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()){
                    String Name = dataSnapshot.child("Persona").getValue().toString();
                    String Fecha = dataSnapshot.child("Fecha").getValue().toString();

                    CamNomTxt5.setText(Name);
                    mTextFechaCam5.setText(Fecha);
                }else {
                    CamNomTxt5.setText(" los Datos no cargaron correctamente"  );}
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabse.child("CAMARA6/Accesos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()){
                    String Name = dataSnapshot.child("Persona").getValue().toString();
                    String Fecha = dataSnapshot.child("Fecha").getValue().toString();

                    CamNomTxt6
                            .setText(Name);
                    mTextFechaCam6.setText(Fecha);
                }else {
                    CamNomTxt6.setText(" los Datos no cargaron correctamente"  );}
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        mDatabse.child("CAMARA2/Equipos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    int p = Integer.parseInt(dataSnapshot.child("Puerta").getValue().toString());
                    if (p == 1) {
                        mtxtpuertaCam2.setText("Abierta");

                        mtxtpuertaCam2.setTextColor(Color.parseColor("#FF0000"));
                        mtxtEstadoCam2.setTextColor(Color.parseColor("#FF0000"));
                        Imagen2.setImageResource(R.drawable.rojocan);
                        men = "Camara 2";
                        alerta(men);
                    } else {
                        mtxtpuertaCam2.setText("Cerrada");

                        mtxtpuertaCam2.setTextColor(Color.parseColor("#008000"));
                        mtxtEstadoCam2.setTextColor(Color.parseColor("#008000"));
                        Imagen2.setImageResource(R.drawable.verde);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabse.child("CAMARA3/Equipos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    int p = Integer.parseInt(dataSnapshot.child("Puerta").getValue().toString());
                    if (p == 1) {
                        mtxtpuertaCam3.setText("Abierta");

                        mtxtpuertaCam3.setTextColor(Color.parseColor("#FF0000"));
                        mtxtEstadoCam3.setTextColor(Color.parseColor("#FF0000"));
                        Imagen3.setImageResource(R.drawable.rojocan);
                        men = "Camara 3";
                        alerta(men);
                    } else {
                        mtxtpuertaCam3.setText("Cerrada");

                        mtxtpuertaCam3.setTextColor(Color.parseColor("#008000"));
                        mtxtEstadoCam3.setTextColor(Color.parseColor("#008000"));
                        Imagen3.setImageResource(R.drawable.verde);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabse.child("CAMARA4/Equipos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    int p = Integer.parseInt(dataSnapshot.child("Puerta").getValue().toString());
                    if (p == 1) {
                        mtxtpuertaCam4.setText("Abierta");

                        mtxtpuertaCam4.setTextColor(Color.parseColor("#FF0000"));
                        mtxtEstadoCam4.setTextColor(Color.parseColor("#FF0000"));
                        Imagen4.setImageResource(R.drawable.rojocan);
                        men = "Camara 4";
                        alerta(men);
                    } else {
                        mtxtpuertaCam4.setText("Cerrada");

                        mtxtpuertaCam4.setTextColor(Color.parseColor("#008000"));
                        mtxtEstadoCam4.setTextColor(Color.parseColor("#008000"));
                        Imagen4.setImageResource(R.drawable.verde);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabse.child("CAMARA5/Equipos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    int p = Integer.parseInt(dataSnapshot.child("Puerta").getValue().toString());
                    if (p == 1) {
                        mtxtpuertaCam5.setText("Abierta");

                        mtxtpuertaCam5.setTextColor(Color.parseColor("#FF0000"));
                        mtxtEstadoCam5.setTextColor(Color.parseColor("#FF0000"));
                        Imagen5.setImageResource(R.drawable.rojocan);
                        men = "Camara 5";
                        alerta(men);
                    } else {
                        mtxtpuertaCam5.setText("Cerrada");

                        mtxtpuertaCam5.setTextColor(Color.parseColor("#008000"));
                        mtxtEstadoCam5.setTextColor(Color.parseColor("#008000"));
                        Imagen5.setImageResource(R.drawable.verde);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabse.child("CAMARA6/Equipos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    int p = Integer.parseInt(dataSnapshot.child("Puerta").getValue().toString());
                    if (p == 1) {
                        mtxtpuertaCam6.setText("Abierta");

                        mtxtpuertaCam6.setTextColor(Color.parseColor("#FF0000"));
                        mtxtEstadoCam6.setTextColor(Color.parseColor("#FF0000"));
                        Imagen6.setImageResource(R.drawable.rojocan);
                        men = "Camara 6";
                        alerta(men);
                    } else {
                        mtxtpuertaCam6.setText("Cerrada");

                        mtxtpuertaCam6.setTextColor(Color.parseColor("#008000"));
                        mtxtEstadoCam6.setTextColor(Color.parseColor("#008000"));
                        Imagen6.setImageResource(R.drawable.verde);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        mDatabse.child("CAMARA1/Equipos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    int p = Integer.parseInt(dataSnapshot.child("Puerta").getValue().toString());
                    if (p == 1) {
                        mtxtpuerta.setText("Abierta");

                        mtxtpuerta.setTextColor(Color.parseColor("#FF0000"));
                        Imagen1.setImageResource(R.drawable.rojocan);
                        men = "Camara 1";
                        alerta(men);
                    } else {
                        mtxtpuerta.setText("Cerrada");

                        mtxtpuerta.setTextColor(Color.parseColor("#008000"));
                        mtxtEstado.setTextColor(Color.parseColor("#008000"));
                        Imagen1.setImageResource(R.drawable.verde);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    public void alerta(String men){
        String mensa = this.men;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Cuidado");
        builder.setMessage("Puerta abierta en " + mensa);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // acción cuando se hace clic en OK
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

}
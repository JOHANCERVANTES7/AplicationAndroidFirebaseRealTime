package com.accmex.camspain

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth

enum class ProviderType {
    BASIC,
    GOOGLE
}


class PrincipalActivity : AppCompatActivity() {
    private lateinit var bottomNavigation: BottomNavigationView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_principal)

        title="Menu"
        // variables y asignamiento de cada variable a un elemento del diseño
        val btnTemp = findViewById<ImageView>(R.id.TempButton)
        val btnCon = findViewById<ImageView>(R.id.ContlButton)
        val btnAcce = findViewById<ImageView>(R.id.AccessButton)
        val txtCont = findViewById<TextView>(R.id.textControl)
        val txtAcces = findViewById<TextView>(R.id.textAcces)
        val txtTemp = findViewById<TextView>(R.id.textTemp)
        val btnHMI = findViewById<ImageView>(R.id.ButtonHMI)
        val txtHMI = findViewById<TextView>(R.id.textHMI)
        val txtBien = findViewById<TextView>(R.id.textBienvenido)
        // subrrallado de titulo
        txtBien.setPaintFlags(txtBien.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)

        val prefs: SharedPreferences.Editor? = getSharedPreferences(getString(R.string.prefs_file), android.content.Context.MODE_PRIVATE).edit()
        // metodos para cambiar de vistas con botones
        btnTemp.setOnClickListener {
            val Intent = Intent(this, TemperatureActivity::class.java)
            startActivity(Intent)
        }
        btnCon.setOnClickListener {
            val Intent = Intent(this, MEnusActivity::class.java)
            startActivity(Intent)
        }
        btnAcce.setOnClickListener {
            val Intent = Intent(this, AccessActivity::class.java)
            startActivity(Intent)
        }
        txtTemp.setOnClickListener {
            val Intent = Intent(this, TemperatureActivity::class.java)
            startActivity(Intent)
        }
        txtCont.setOnClickListener {
            val Intent = Intent(this, MEnusActivity::class.java)
            startActivity(Intent)
        }
        txtAcces.setOnClickListener {
            val Intent = Intent(this, AccessActivity::class.java)
            startActivity(Intent)
        }
        btnHMI.setOnClickListener{
            val Intent = Intent(this, HMIActivity::class.java)
            startActivity(Intent)
        }
        txtHMI.setOnClickListener{
            val Intent = Intent(this, HMIActivity::class.java)
            startActivity(Intent)
        }






        bottomNavigation = findViewById(R.id.bottom_navigation)
        // navbar de la parte inferior
        bottomNavigation.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {

                    AlertDialog.Builder(this)
                        .setTitle("Cerrar aplicación")
                        .setMessage("¿Está seguro de que desea cerrar la aplicación?")
                        .setPositiveButton("Sí") { _, _ -> finishAffinity() }
                        .setNegativeButton("No", null)
                        .show()

                    true
                }
                R.id.navigation_dashboard -> {
                    FirebaseAuth.getInstance().signOut()
                    val Intent = Intent(this, MainActivity::class.java)
                    startActivity(Intent)
                    true
                }
                R.id.navigation_notifications -> {
                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://accmex.com.mx/"))
                    startActivity(browserIntent)
                    true
                }

                else -> false
            }
        }
    }
}


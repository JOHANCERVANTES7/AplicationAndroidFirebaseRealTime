package com.accmex.camspain;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;


public class GraficaActivity2 extends AppCompatActivity {

    private DatabaseReference mDatabse;

   public LineChart lineChart;
   public ArrayList<Entry> values;


    Timer timer;
    int value = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grafica2);

        setTitle("ACCMEX");

        lineChart = findViewById(R.id.chart);
        lineChart.getDescription().setText("Tiempo");

        values = new ArrayList<>();

        mDatabse = FirebaseDatabase.getInstance().getReference();
        Map<String , Object> EquiposMap = new HashMap<>();
        EquiposMap.put("Tiempo",0);
        mDatabse.child("CAMARA2/Temperatura/Sensor1").updateChildren(EquiposMap);

        UpdateValue();


        mDatabse.child("CAMARA2/Temperatura/Sensor1").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot  dataSnapshot) {
                if (dataSnapshot.exists()){
                    double Temp = Double.parseDouble(dataSnapshot.child("Valor").getValue().toString());

                    double Time = Double.parseDouble(dataSnapshot.child("Tiempo").getValue().toString());

                    values.add(new Entry ((float) Time, (float) Temp));
                    LineDataSet lineDataSet = new LineDataSet(values,"Temperatura");
                    lineDataSet.setColor(Color.RED);
                    lineDataSet.setFormLineWidth(34f);
                    LineData lineData = new LineData(lineDataSet);
                    lineChart.setData(lineData);
                    lineChart.invalidate();


                    }

                }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void UpdateValue() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                value++;

                Map<String , Object> EquiposMap = new HashMap<>();
                EquiposMap.put("Tiempo",value);
                mDatabse.child("CAMARA2/Temperatura/Sensor1").updateChildren(EquiposMap);
            }
        }, 0, 10 * 1000);
    }

}